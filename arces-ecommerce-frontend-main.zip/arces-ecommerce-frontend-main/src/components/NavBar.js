import React from 'react'
import Cart from './NavBar/Cart'
import HamburgerButton from './NavBar/HamburgerButton'
import SearchBar from './NavBar/SearchBar'

function NavBar() {
    return (
        <div className='w3-top'>
            <div className='w3-bar w3-orange w3-card w3-row'>
                <div className='w3-bar-item w3-button w3-padding-large w3-col l4 m2 s2'>
                    <img src="/img/logo-low.png" alt="Amazzon" className="w3-hide-small w3-hide-medium" />
                    <img src="/img/logo-small-low.png" alt="Amazzon" className="w3-hide-large" />
                </div>

                <div className='w3-bar-item w3-padding-large w3-left  w3-col l6 m6 s8'><SearchBar /></div>
                <div className='w3-bar-item w3-button w3-padding-large w3-col l1 m2 w3-hide-small'><Cart /></div>
                <div className='w3-bar-item w3-button w3-padding-large w3-col l1 m2 s2'><HamburgerButton /></div>
            </div>
        </div>
    )
}

export default NavBar