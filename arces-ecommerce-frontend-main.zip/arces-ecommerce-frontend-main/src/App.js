import logo from './logo.svg';
import './App.css';
import './w3.css';

import React from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Products from './views/Products';
import NavBar from './components/NavBar';

export default function App() {
  return (
    <BrowserRouter>
      <NavBar />
      <Routes>
        <Route path="/" element={<Products/>} />
      </Routes>
    </BrowserRouter>
  );
};